using System;
using System.IO;
using System.Collections.Generic;

using SolverLibrary;


namespace ProjecteulerProblems
{

    class Program
    {
        static void Main(string[] args)
        {
            var problemlist = new List<Problem>();

            DoTitle();

            if (GetProblemList(problemlist))
            {
                PrintList(problemlist);
            }
        }



        static void DoTitle()
        {
            Console.Title = "Project Euler Solutions Generator";
            string title = @"
______          _           _     _____      _                                             
| ___ \        (_)         | |   |  ___|    | |                                            
| |_/ / __ ___  _  ___  ___| |_  | |__ _   _| | ___ _ __                                   
|  __/ '__/ _ \| |/ _ \/ __| __| |  __| | | | |/ _ \ '__|                                  
| |  | | | (_) | |  __/ (__| |_  | |__| |_| | |  __/ |                                     
\_|  |_|  \___/| |\___|\___|\__| \____/\__,_|_|\___|_|                                     
              _/ |                                                                         
             |__/                                                                          
 _____       _       _   _                   _____                           _             
/  ___|     | |     | | (_)                 |  __ \                         | |            
\ `--.  ___ | |_   _| |_ _  ___  _ __  ___  | |  \/ ___ _ __   ___ _ __ __ _| |_ ___  _ __ 
 `--. \/ _ \| | | | | __| |/ _ \| '_ \/ __| | | __ / _ \ '_ \ / _ \ '__/ _` | __/ _ \| '__|
/\__/ / (_) | | |_| | |_| | (_) | | | \__ \ | |_\ \  __/ | | |  __/ | | (_| | || (_) | |   
\____/ \___/|_|\__,_|\__|_|\___/|_| |_|___/  \____/\___|_| |_|\___|_|  \__,_|\__\___/|_|   
";
            Console.WriteLine(title);
        }



        static bool GetProblemList(List<Problem> input)
        {
            try
            {
                using (var reader = new StreamReader(@"problems.csv"))
                {
                    while (!reader.EndOfStream)
                    {
                        var line = reader.ReadLine();
                        var values = line.Split(',');

                        int temp = 0;
                        int.TryParse(values[0], out temp);
                        Problem newprob = new Problem(temp, values[1], values[2]);
                        input.Add(newprob);
                    }
                }
                return true;
            }
            catch
            {
                Console.WriteLine("There was an error opening the list of solved problems");
                return false;
            }
        }



        static void PrintList(List<Problem> input)
        {
            string temp = null;
            int selection = 0;

            foreach (Problem probs in input)
            {
               probs.printdetails();
            }



            Console.WriteLine("\nPlease enter the 3 digit Project Euler problem number from the list above to solve it:");
            temp = Console.ReadLine();
            int.TryParse(temp, out selection);

            bool found = false;

            for (int i = 0; i < input.Count && !found; i++)
            {
                found = input[i].checknumber(selection);
            }


            if (found)
            {
                switch (selection)
                {
                    // This is a terrible solution - the idea of my program was that all I would have to do to add further problems was;
                    //      Add problem to problems.csv
                    //      Add a class derived from Solver. 
                    // I would have much prefered to produce something like;
                    // https://stackoverflow.com/questions/2247598/how-do-i-instantiate-a-class-given-its-string-name
                    // https://social.msdn.microsoft.com/Forums/vstudio/en-US/4d915685-a728-42d9-99e0-02e16dc159d1/reflection-instantiate-class-via-a-string?forum=netfxbcl
                    //
                    // Couldn't make it work in a reasonable time frame. 

                    case 001: //Complete and Works
                        Console.WriteLine("Problem 001 Selected");
                        Solver001 selected001 = new Solver001();
                        break;

                    case 131: //Complete and Works
                        Console.WriteLine("Problem 131 Selected");
                        Solver131 solver131 = new Solver131();
                        break;

                    case 153: //Complete and Works
                        Console.WriteLine("Problem 153 Selected");
                        Solver153 solver153 = new Solver153();
                        break;
                }
            }
            

            if (!found)
            {
                Console.WriteLine("\n\nYou've chosen a problem for which I've no solution.\n");
                PrintList(input);
            }
        }


        // Datastorage class - read from problems.csv
        class Problem
        {
            public Problem(int number, string name, string address)
            {
                probnumber = number;
                probname = name;
                proburl = address;
            }

            // Standard true/false search function.
            public bool checknumber(int search)
            {
                if (probnumber == search)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }

            // Standard print function. 
            public void printdetails()
            {
                Console.WriteLine(probnumber + " - " + probname + " - " + proburl);
            }


            private

            int probnumber = 0;
            string probname = null;
            string proburl = null;
        };
    }
}
