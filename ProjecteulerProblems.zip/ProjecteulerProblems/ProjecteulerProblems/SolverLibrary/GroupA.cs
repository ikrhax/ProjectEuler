﻿using System;

namespace SolverLibrary
{
    public class Solver
    {
        public Solver(int number, string name, string address)
        {
            solnumber = number;
            solname = name;
            solurl = address;
            PrintSolver();
        }

        private void PrintSolver()
        {
            Console.WriteLine("\n\nYou've chosen to solve problem " + solnumber + " - " + solname + " - " + solurl);
        }

        public int Number
        {
            get { return solnumber; }
            set { solnumber = value; }
        }

        public string Solname
        {
            get { return solname; }
            set { solname = value; }
        }

        public string Solurl
        {
            get { return solurl; }
            set { solurl = value; }
        }


        protected

        int solnumber = 0;
        string solname;
        string solurl;
    }





    public class Problem101 : Solver
    {
        public Problem101(int number, string name, string address) : base(number, name, address)
        {

            Console.WriteLine("101 Custom Class");
        }

    }
}


/*
 * 
 * 
 * 
 * 
 * 
 * https://www.mathblog.dk/project-euler-101-optimum-polynomial-function/
 * https://www.mathblog.dk/project-euler-111-10-digit-primes-repeated-digits/
 * https://mukeshiiitm.wordpress.com/2011/02/09/project-euler-problem-153/
 * https://euler.stephan-brumme.com/156/
 * https://euler.stephan-brumme.com/215/
 * https://euler.stephan-brumme.com/291/
 * https://www.mathworks.com/matlabcentral/answers/216686-simulation-problem-project-euler-307
 * http://www.drdobbs.com/cpp/project-euler-problem-328/229401218
 * http://luqi-code.blogspot.com/2015/10/project-euler-493-under-rainbow.html
 * https://github.com/roosephu/project-euler/blob/master/585.cpp
 * https://web.williams.edu/Mathematics/sjmiller/public_html/pbook/SJMiller1701_EulerSolns.pdf -597
 * 
 * 
 * https://github.com/luckytoilet/projecteuler-solutions/blob/master/Solutions.md
 * 
 * 

