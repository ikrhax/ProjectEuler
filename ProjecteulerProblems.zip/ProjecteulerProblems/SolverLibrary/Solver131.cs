﻿using System;

/*   https://projecteuler.net/problem=131 // Problem
 *  
 *   https://stackoverflow.com/questions/8900458/perfect-powers-check 
 *   
 *   https://www.topperlearning.com/doubts-solutions/show-that-1728-is-a-perfect-cube-what-is-the-number-whose-cube-is-1728-68yfkdecc
 *   
 */

namespace SolverLibrary
{ 
    public class Solver131 : Solver
    {
        protected override void Main()
        {
            Console.Write("Welcome to the Solver for the Project Euler Problem 131 - Prime Cube Partnership\n\n");


            // After reading an interesting discussion centered around the idea that all things must be perfect cubes the balance the equation, 
            // and that we are looking for the difference of two numbers. 
            // Itterate through to find which cubes, when subtracted one from the other, equal limit. 

            while ((Math.Pow(big, 3) - Math.Pow(little, 3)) < limit)
            {
                big++;
                little++;
                // Function is not perfect as little ends up bigger than big.
            }              
         
            //Now that we know what the upper limit of our cubes should be, itterate through checking for primes. 
            for (int i = 1; i < little; i++)
            {
                if (IsPrime((i + 1) * (i + 1) * (i + 1) - i * i * i))
                    result++;
            }


            Console.Write("\n\nThe number of Primes is: " + result);
            Console.Write("\nPress any key to continue");
            Console.ReadKey();
        }


        private
        const int limit = 1000000;
        int big = 1;
        int little = 0;
        int result = 0;
    }
}
