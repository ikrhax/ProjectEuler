﻿using System;

namespace SolverLibrary
{
    // This is my abstract solver class, from which all my solvers will be derived. 
    // As I progress through any of my Euler solutions I will add 'core' mathematical functions here so they are available to all my solutions. 
    
    public abstract class Solver
    {
        public Solver()
        {
            Main();
        }


        protected virtual void Main()
        {
            Console.WriteLine("If you see this, you've forgotten to override the base class' virtual Main, nerd");
        }

        
        // Function to identify prime numbers - overloaded for any sort of instance. 
        protected static bool IsPrime(int number)
        {
            if (number == 1) return false;
            if (number == 2) return true;

            if (number % 2 == 0) return false;

            for (int i = 3; i < number; i += 2)
            {
                if (number % i == 0) return false;
            }
            return true;
        }


        protected static bool IsPrime(long number)
        {
            if (number == 1) return false;
            if (number == 2) return true;

            if (number % 2 == 0) return false;

            for (long i = 3; i < number; i += 2)
            {
                if (number % i == 0) return false;
            }
            return true;
        }


        protected static bool IsPrime(ulong number)
        {
            if (number == 1) return false;
            if (number == 2) return true;

            if (number % 2 == 0) return false;

            for (ulong i = 3; i < number; i += 2)
            {
                if (number % i == 0) return false;
            }
            return true;
        }


        protected static double factorial(int number)
        {
            // Suspected problem with this function. 
            Console.WriteLine("I'm doing a factorial");
            double result = 1;
            while (number != 1)
            {
                result = result * number;
                number = number - 1;
            }
            return result;            
        }


        public static double cubicroot(double number)
        {
            double root = (System.Math.Pow(number, (1.0 / 3.0))); 
            return root;
        }

    }
}