﻿using System;

/*   
 *   https://projecteuler.net/problem=001 // Problem
 */


namespace SolverLibrary
{
    public class Solver001 : Solver
    {
        protected override void Main()
        {
            Console.Write("Welcome to the Solver for the Project Euler Problem 001 - Multiples of 3 or 5\n\n");

            // Simple loop to check for multiples
            for (int i = 0; i <= limit; i++)
            {
                if((i % 3 == 0)||(i % 5 == 0))
                {
                    // Incriment when one is found.
                    sum = sum + i;
                }
            }

            // Standard print answer. 
            Console.Write("\n\nThe sum is: " + sum);
            Console.Write("\nPress any key to continue");
            Console.ReadKey();

        }

        private
        const int limit = 1000;
        long sum = 0;
    }
}
