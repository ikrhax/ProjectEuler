﻿using System;

/*   https://projecteuler.net/problem=153 // Problem
 *   
 *   https://www.meetup.com/Math-for-People/events/242724085/ //News on the problem. 
 *  
 *   http://mathworld.wolfram.com/GaussianInteger.html // Basic definition of Gaussian Integer. Interesting properties. 
 * 
 *   https://projecteuler.chat/viewtopic.php?t=1927 // Interesting pattern detailed here. 
 *   
 *   https://projecteuler.net/thread=153 // Discussion of using bitwise shifts?
 *   
 *   https://codereview.stackexchange.com/questions/173413/calculating-gcd-for-2-integers // cgd function modeled from....
 *   
 *   https://math.stackexchange.com/questions/1166737/general-formula-for-iterated-cumulative-sum // Worth trying to make it work? Turns out no speed gain, potential problem with factorial funciton.
 *   https://math.stackexchange.com/questions/1504639/how-to-simplify-a-sum-of-complex-divisors  // Far too complicated.  
 *   http://mathworld.wolfram.com/DivisorFunction.html // I've now run out of time. 
 *   
 *   Needless to say, after reading far to many notes I needed to take some time out to refocus. 
 */

namespace SolverLibrary
{
    public class Solver153 : Solver
    {
        protected override void Main()
        {
            Console.Write("Welcome to the Solver for the Project Euler Problem 153 - Investigating Gaussian Integers\n\n");


            //Calculate the cumulative total through to limit of n
            for (int i = 1; i <= limit; i++)
            {
                sum = sum + (limit / i * i);
            }
            

            //Outer loop.
            for (int i = 1; Math.Pow(i, 2) < limit; i++)
            {
                //Use a loop to check for GCD within the range.
                for (int j = 1; j <= i; j++)
                {
                    //If GCD...
                    if (gcd(i, j) == 1)
                    {
                        //Calculate initial value post gcd calculation.
                        valueOne = (i * i + j * j);

                        // I've chosen to break up the variables here for my own clarity of thought. 
                        tempOne = (i + j);
                        tempTwo = 2 * (i + j);

                        //Bitwise conditional comparison - if i = j compared to i + j, shift. 
                        valueTwo = (i == j) ? tempOne : tempTwo;

                        //Final sweep to calculate the sum.
                        for (int k = 1; valueOne * k <= limit; k++)
                        {
                            sum = sum + (k * valueTwo * (limit / (valueOne * k)));
                        }
                    }
                }
            }

            answer = sum;
        
            //Standard print out of answer. 
            Console.WriteLine("\n\nThe Answer is " + answer);
            Console.Write("\n\nPress any key to continue");
            Console.ReadKey();
        }


        //Greatest Common Divisor function - please see the above for link. 
        private long gcd(int x, int y)
        {
            while (y != 0)
            {
                int tmp = x % y;
                x = y;
                y = tmp;
            }

            return x;
        }


        //Data members. 
        private

        const int limit = 100000000;
        long sum = 0;
        long answer = 0;
        int tempOne = 0;
        int tempTwo = 0;
        int valueTwo = 0;
        int valueOne = 0;
    }
}
